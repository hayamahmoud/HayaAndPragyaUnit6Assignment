/*
P Shaw
November 6, 2023
The Student class represents a student with a name and three test scores.
 */
package shawarray3;

public class Student {

    private String name; // Student's name
    private int test1;   // Test score 1
    private int test2;   // Test score 2
    private int test3;   // Test score 3

    /**
     * Constructs a Student object with a given name and test scores.
     *
     * @param name The name of the student.
     * @param test1 The score of the first test.
     * @param test2 The score of the second test.
     * @param test3 The score of the third test.
     */
    public Student(String name, int test1, int test2, int test3) {
        this.name = name;
        this.test1 = test1;
        this.test2 = test2;
        this.test3 = test3;
    }

    /**
     * Get the name of the student.
     *
     * @return The name of the student.
     */
    public String getName() {
        return name;
    }

    /**
     * Get the score of the first test.
     *
     * @return The score of the first test.
     */
    public int getTest1() {
        return test1;
    }

    /**
     * Get the score of the second test.
     *
     * @return The score of the second test.
     */
    public int getTest2() {
        return test2;
    }

    /**
     * Get the score of the third test.
     *
     * @return The score of the third test.
     */
    public int getTest3() {
        return test3;
    }

    /**
     * Calculate and return the average of the test scores.
     *
     * @return The average of the test scores.
     */
    public double getAverage() {
        return (test1 + test2 + test3) / 3.0;
    }

    /**
     * Get the highest test score among the three tests.
     *
     * @return The highest test score.
     */
    public int getHighestMark() {
        return Math.max(Math.max(test1, test2), test3);
    }

    /**
     * Set the score of the first test.
     *
     * @param test1 The new score for the first test.
     */
    public void setTest1(int test1) {
        this.test1 = test1;
    }

    /**
     * Set the score of the second test.
     *
     * @param test2 The new score for the second test.
     */
    public void setTest2(int test2) {
        this.test2 = test2;
    }

    /**
     * Set the score of the third test.
     *
     * @param test3 The new score for the third test.
     */
    public void setTest3(int test3) {
        this.test3 = test3;
    }
}

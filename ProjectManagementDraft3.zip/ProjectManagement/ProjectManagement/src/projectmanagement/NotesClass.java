/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectmanagement;

/**
 *
 * @author hamah5330
 */
public class NotesClass {
    
    protected String contentTitle; 
    protected String notes; 
    
    /**
     * 
     * @param contentTitle 
     */
    public NotesClass(String contentTitle) {
        this.contentTitle = contentTitle; 
    }
    
    /**
     * 
     * @param contentTitle
     * @param notes 
     */
    public NotesClass(String contentTitle, String notes) {
        this(contentTitle); 
        this.notes = notes; 
    }
    
    /**
     * 
     * @return 
     */
    public String getContentTitle() {
        return this.contentTitle; 
    }
    
    /**
     * 
     * @param title 
     */
    public void setContentTitle(String title) {
        this.contentTitle = title; 
    }
    
    /**
     * 
     * @return 
     */
    public String getNotes() {
        return this.notes; 
    }
    
    /**
     * 
     * @param notes 
     */
    public void setNotes(String notes) {
        this.notes = notes; 
    }
    
    /**
     * 
     * @param other
     * @return 
     */
    public boolean equals(NotesClass other) {
        return this.notes.equals(other.getNotes()); 
    }
    
    /**
     * 
     * @return 
     */
    public NotesClass clone() {
        NotesClass n2; 
        n2 = new NotesClass(contentTitle,notes); 
        return n2; 
    }
    
    /**
     * 
     * @return 
     */
    public String toString() {
        return "Content Title: " + this.contentTitle + "\nNotes: " + this.notes; 
    }
    
}
